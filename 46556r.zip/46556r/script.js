//------Hide and show element-----

  $(document).ready(function(){
    $("#hide").click(function(){
      $(".hide-text").hide();
    });
    $("#show").click(function(){
      $(".hide-text").show();
    });
  });
//-----fadeOut() fadeIn() fadeToggle()----------

  $(document).ready(function(){
    $('#btnFadeOut').click(function(){
      $('#img_holder').fadeOut(3000, function(){
        
      });
    });
    $('#btnFadeIn').click(function(){
      $('#img_holder').fadeIn(3000);
    });
    $('#btnFadeTog').click(function(){
      $('#img_holder').fadeToggle(1000);
    });
  });

  //------slideUp(), and slideDown()----slideToggle()---
  $(document).ready(function(){
	$('#btnSlideDown').click(function(){
    $('#box').slideDown(3000);
  });
});
  $(document).ready(function(){
  $('#btnSlideUp').click(function(){
    $('#box').slideUp(3000);
  });
});
$(document).ready(function(){
  $('#btnSlideTog').click(function(){
    $('#box').slideToggle(3000);
  });
  $('#btnStop').click(function(){
    $('#box').stop();
  });
});

  //-----------Animatee---------------
  $(document).ready(function(){
    $('#moveRight').click(function(){
      $('#box2').animate({
        left: 500,
        height: '300px',
        width:'300px',
        opacity: '0.5'
      });
    });
  });
  $(document).ready(function(){
    $('#moveLeft').click(function(){
      $('#box2').animate({
        left: 0,
        height: '100px',
        width: '100px',
        opacity:'1'
      });
    });
  });
  $(document).ready(function(){
    $('#moveAround').click(function(){
      var box = $('#box2');
      box.animate({
        left: 300
      });
      box.animate({
        top: 300
      });
      box.animate({
        left:0,
        top: 300
      });
      box.animate({
        left: 0,
        top:0
      });
    });
  });

//----------CSS Classes------------

$(document).ready(function(){
  $("#btnclasses").click(function(){
    $(".h1design").toggleClass("blue");
  });
});

  //------------Add after()-----------------------
  function afterText() {
    var txt1 = "<b>I </b>";           
    var txt2 = $("<i></i>").text("love "); 
    var txt3 = document.createElement("b");   
    txt3.innerHTML = "jQuery!";
    $(".img-after-text").after(txt1, txt2, txt3);    
  }

  //--------innerWidth() innerHeight()-------------
  $(document).ready(function(){
    $(".div-dimensions").click(function(){
      var txt = "";
      txt += "Width of div: " + $("#div2").width() + "</br>";
      txt += "Height of div: " + $("#div2").height() + "</br>";
      txt += "Inner width of div: " + $("#div2").innerWidth() + "</br>";
      txt += "Inner height of div: " + $("#div2").innerHeight();
      $("#div2").html(txt);
    });
  });

  //----------remove()--------------
  $(document).ready(function(){
    $("#div1").click(function(){
      $("#div1").remove();
    });
  }); 


  //-------slideToggle----------
  $(document).ready(function(){
    $("#flip").click(function(){
      $("#panel").slideToggle("slow");
    });
  });


